import { serve } from "https://deno.land/std@0.208.0/http/server.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    
    // Parse query parameters
    const cursor = url.searchParams.get('cursor') || '0';
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '500'), 2000);
    const offset = parseInt(cursor, 10);

    // Get credentials if available
    let credentials = null;
    try {
      const body = await req.json();
      credentials = body;
    } catch (e) {
      // Continue without credentials for demo
    }

    // Generate synthetic Ontario pricing data based on IESO patterns
    const generateOntarioPricingData = (startOffset: number, count: number) => {
      const rows = [];
      const baseDate = new Date('2023-01-01');
      
      // Ontario pricing nodes (simplified set)
      const nodes = [
        { name: "TORONTO.TR_230_WTS", zone: "TORONTO" },
        { name: "OTTAWA.OT_230_HWY", zone: "OTTAWA" },
        { name: "NORTHWEST.NW_115_CNS", zone: "NORTHWEST" }, 
        { name: "NIAGARA.NG_230_BRK", zone: "NIAGARA" },
        { name: "SOUTHWEST.SW_500_NAS", zone: "SOUTHWEST" },
        { name: "BRUCE.BR_500_TSS", zone: "BRUCE" },
        { name: "NORTHEAST.NE_230_TMS", zone: "NORTHEAST" },
        { name: "EAST.ES_115_COR", zone: "EAST" }
      ];
      
      for (let i = 0; i < count; i++) {
        // Calculate time offset (5-minute intervals)
        const intervalOffset = Math.floor((startOffset + i) / nodes.length);
        const nodeIndex = (startOffset + i) % nodes.length;
        const node = nodes[nodeIndex];
        
        const currentDate = new Date(baseDate);
        currentDate.setMinutes(currentDate.getMinutes() + intervalOffset * 5);
        
        const hour = currentDate.getHours();
        const month = currentDate.getMonth();
        const dayOfWeek = currentDate.getDay();
        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
        
        // Base energy price (varies by season and time)
        let energyPrice = 35; // Base CAD$/MWh
        
        // Seasonal variations
        if (month >= 5 && month <= 8) energyPrice += 15; // Summer
        if (month >= 11 || month <= 2) energyPrice += 8;  // Winter
        
        // Daily patterns
        if (hour >= 7 && hour <= 18 && !isWeekend) {
          energyPrice += 20; // Business hours
        } else if (hour >= 19 && hour <= 22) {
          energyPrice += 10; // Evening peak
        }
        
        // Weekend adjustments
        if (isWeekend) energyPrice -= 8;
        
        // Zone-specific adjustments
        switch (node.zone) {
          case "TORONTO": energyPrice += 5; break;  // Higher urban prices
          case "NORTHWEST": energyPrice -= 3; break; // Remote, typically lower
          case "BRUCE": energyPrice -= 2; break;    // Near nuclear generation
        }
        
        // Add price volatility
        energyPrice += (Math.random() - 0.5) * 20;
        energyPrice = Math.max(energyPrice, 10); // Floor price
        
        // Occasionally add price spikes
        if (Math.random() < 0.002) {
          energyPrice += Math.random() * 200; // Price spike
        }
        
        // Calculate congestion and loss components
        const congestionPrice = (Math.random() - 0.5) * 6;
        const lossPrice = Math.random() * 3;
        const lmpPrice = energyPrice + congestionPrice + lossPrice;
        
        rows.push({
          datetime: currentDate.toISOString().slice(0, 19).replace('T', ' '),
          node_name: node.name,
          lmp_price: Math.round(lmpPrice * 100) / 100,
          energy_price: Math.round(energyPrice * 100) / 100,
          congestion_price: Math.round(congestionPrice * 100) / 100,
          loss_price: Math.round(lossPrice * 100) / 100,
          zone: node.zone,
          market_date: currentDate.toISOString().slice(0, 10),
          interval_ending: currentDate.toTimeString().slice(0, 5)
        });
      }
      
      return rows;
    };

    const rows = generateOntarioPricingData(offset, limit);
    const hasMore = offset + limit < 2500000; // Based on research: ~2.5M records
    const nextCursor = hasMore ? (offset + limit).toString() : null;

    const responseData = {
      rows,
      metadata: {
        offset,
        limit,
        returned: rows.length,
        hasMore,
        totalEstimate: 2500000,
        dataSource: "Demo Mode - Generated Ontario LMP Price Data",
        generatedAt: new Date().toISOString()
      }
    };

    const responseHeaders = {
      ...corsHeaders,
      'Content-Type': 'application/json'
    };

    if (nextCursor) {
      responseHeaders['x-next-cursor'] = nextCursor;
    }

    return new Response(JSON.stringify(responseData), {
      headers: responseHeaders
    });

  } catch (error) {
    console.error('Stream error:', error);
    
    return new Response(JSON.stringify({
      error: {
        code: 'STREAM_ERROR',
        message: error.message
      }
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
})
