import { serve } from "https://deno.land/std@0.208.0/http/server.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    
    // Extract source and dataset from path
    const source = pathParts[pathParts.length - 2] || 'ieso';  
    const dataset = pathParts[pathParts.length - 1] || 'ontario_prices';

    // Get credentials if needed (IESO may require different auth)
    let credentials = null;
    try {
      const body = await req.json();
      credentials = body;
    } catch (e) {
      // Continue without credentials for demo
    }

    // Define schema based on IESO LMP pricing research
    const schema = {
      fields: [
        {
          name: "datetime",
          type: "string", 
          description: "Timestamp in EST (YYYY-MM-DD HH:mm:ss)"
        },
        {
          name: "node_name",
          type: "string",
          description: "LMP pricing node identifier"
        },
        {
          name: "lmp_price",
          type: "number",
          description: "Locational Marginal Price in CAD$/MWh"
        },
        {
          name: "energy_price",
          type: "number", 
          description: "Energy component of LMP in CAD$/MWh"
        },
        {
          name: "congestion_price",
          type: "number",
          description: "Congestion component in CAD$/MWh"
        },
        {
          name: "loss_price", 
          type: "number",
          description: "Loss component in CAD$/MWh"
        },
        {
          name: "zone",
          type: "string",
          description: "Pricing zone (e.g., NORTHWEST, TORONTO, etc.)"
        },
        {
          name: "market_date",
          type: "string",
          description: "Market date in YYYY-MM-DD format"
        },
        {
          name: "interval_ending",
          type: "string",
          description: "5-minute interval ending time"
        }
      ]
    };

    // Sample data reflecting Ontario electricity pricing patterns
    const sampleRows = [
      {
        datetime: "2023-07-15 14:30:00",
        node_name: "TORONTO.TR_230_WTS",
        lmp_price: 45.67,
        energy_price: 42.15,
        congestion_price: 2.89,
        loss_price: 0.63,
        zone: "TORONTO", 
        market_date: "2023-07-15",
        interval_ending: "14:30"
      },
      {
        datetime: "2023-07-15 14:35:00",
        node_name: "NORTHWEST.NW_115_CNS", 
        lmp_price: 38.92,
        energy_price: 42.15,
        congestion_price: -4.12,
        loss_price: 0.89,
        zone: "NORTHWEST",
        market_date: "2023-07-15", 
        interval_ending: "14:35"
      },
      {
        datetime: "2023-12-20 18:15:00",
        node_name: "OTTAWA.OT_230_HWY",
        lmp_price: 78.34,
        energy_price: 75.20,
        congestion_price: 1.98,
        loss_price: 1.16,
        zone: "OTTAWA",
        market_date: "2023-12-20",
        interval_ending: "18:15"
      }
    ];

    const manifestData = {
      dataset: `${source}/ontario_prices`,
      version: "1.0",
      schema,
      sampleRows,
      estimatedRows: 2500000, // ~1000 nodes * 288 intervals/day * ~8-10 years
      recommendedLimit: 500,   // Smaller batches for price data
      metadata: {
        description: "Ontario electricity locational marginal pricing (LMP) data",
        source: "Demo Mode - Static Data",
        lastUpdated: "2025-01-01T00:00:00Z",
        coverage: {
          dateRange: "2015-01 to 2023-12",
          granularity: "5-minute intervals",
          timezone: "EST",
          pricingNodes: "~1000 LMP nodes across Ontario",
          priceRange: "Typically CAD$20-100/MWh, can spike to CAD$3000/MWh",
          zones: ["TORONTO", "OTTAWA", "NIAGARA", "SOUTHWEST", "NORTHWEST", "NORTHEAST", "EAST", "BRUCE"]
        }
      }
    };

    return new Response(JSON.stringify(manifestData), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('Manifest error:', error);
    
    return new Response(JSON.stringify({
      error: {
        code: 'MANIFEST_ERROR',
        message: error.message
      }
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
})
