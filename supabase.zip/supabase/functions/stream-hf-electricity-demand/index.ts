import { serve } from "https://deno.land/std@0.208.0/http/server.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    
    // Parse query parameters
    const cursor = url.searchParams.get('cursor') || '0';
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '1000'), 5000);
    const offset = parseInt(cursor, 10);

    // Get Hugging Face token if available
    let hfToken = Deno.env.get('HF_TOKEN');
    if (!hfToken) {
      try {
        const body = await req.json();
        hfToken = body.hfToken || body.huggingFaceToken;
      } catch (e) {
        // Continue without token for demo
      }
    }

    // Generate synthetic smart meter electricity demand data with weather features
    const generateSmartMeterData = (startOffset: number, count: number) => {
      const rows = [];
      const baseDate = new Date('2023-01-01');
      
      // European locations with different patterns
      const locations = [
        { id: "UK_LONDON", baseDemand: 2.1, tempVariance: 15 },
        { id: "DE_BERLIN", baseDemand: 1.8, tempVariance: 18 },
        { id: "FR_PARIS", baseDemand: 2.3, tempVariance: 14 },
        { id: "ES_MADRID", baseDemand: 1.9, tempVariance: 22 },
        { id: "IT_ROME", baseDemand: 2.0, tempVariance: 20 },
        { id: "NL_AMSTERDAM", baseDemand: 1.7, tempVariance: 12 }
      ];
      
      const householdsPerLocation = 50;
      const totalHouseholds = locations.length * householdsPerLocation;
      
      for (let i = 0; i < count; i++) {
        // Calculate time offset (15-minute intervals)
        const intervalOffset = Math.floor((startOffset + i) / totalHouseholds);
        const householdIndex = (startOffset + i) % totalHouseholds;
        
        const locationIndex = Math.floor(householdIndex / householdsPerLocation);
        const location = locations[locationIndex];
        const householdNum = householdIndex % householdsPerLocation + 1;
        
        const currentDate = new Date(baseDate);
        currentDate.setMinutes(currentDate.getMinutes() + intervalOffset * 15);
        
        const hour = currentDate.getHours();
        const month = currentDate.getMonth();
        const dayOfWeek = currentDate.getDay();
        const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;
        
        // Temperature simulation (seasonal + daily variation)
        const avgTempByMonth = [2, 4, 8, 12, 17, 20, 22, 21, 18, 13, 7, 3];
        const baseTemp = avgTempByMonth[month];
        const dailyTempVariation = Math.sin((hour - 6) / 24 * 2 * Math.PI) * 5;
        const temperature = baseTemp + dailyTempVariation + (Math.random() - 0.5) * 4;
        
        // Weather features
        const humidity = 45 + Math.random() * 40; // 45-85%
        const windSpeed = Math.random() * 12; // 0-12 m/s
        const solarIrradiance = hour >= 6 && hour <= 18 ? 
          Math.max(0, 800 * Math.sin((hour - 6) / 12 * Math.PI) * (0.8 + Math.random() * 0.4)) : 0;
        
        // Electricity demand calculation
        let demand = location.baseDemand;
        
        // Daily pattern - higher in morning and evening
        if (hour >= 6 && hour <= 9) demand *= 1.4;  // Morning peak
        else if (hour >= 18 && hour <= 22) demand *= 1.6; // Evening peak
        else if (hour >= 10 && hour <= 17 && !isWeekend) demand *= 1.2; // Daytime
        else if (hour >= 0 && hour <= 5) demand *= 0.6; // Night
        
        // Weekend patterns - more consistent throughout day
        if (isWeekend) {
          demand *= 0.85;
          if (hour >= 9 && hour <= 21) demand *= 1.3;
        }
        
        // Seasonal heating/cooling
        if (temperature < 10) demand += (10 - temperature) * 0.15; // Heating
        if (temperature > 25) demand += (temperature - 25) * 0.12; // Cooling
        
        // Household-specific variance
        demand *= (0.7 + Math.random() * 0.6); // Individual patterns
        
        // Add some noise
        demand += (Math.random() - 0.5) * 0.3;
        demand = Math.max(demand, 0.1); // Minimum consumption
        
        rows.push({
          datetime: currentDate.toISOString(),
          household_id: `HH_${householdNum.toString().padStart(3, '0')}_${location.id}`,
          electricity_demand: Math.round(demand * 1000) / 1000,
          temperature: Math.round(temperature * 10) / 10,
          humidity: Math.round(humidity * 10) / 10,
          wind_speed: Math.round(windSpeed * 10) / 10,
          solar_irradiance: Math.round(solarIrradiance),
          location: location.id,
          day_of_week: dayOfWeek,
          hour: hour
        });
      }
      
      return rows;
    };

    const rows = generateSmartMeterData(offset, limit);
    const hasMore = offset + limit < 8760000; // Based on estimate: 8.76M records
    const nextCursor = hasMore ? (offset + limit).toString() : null;

    const responseData = {
      rows,
      metadata: {
        offset,
        limit,
        returned: rows.length,
        hasMore,
        totalEstimate: 8760000,
        dataSource: "Demo Mode - Generated Smart Meter Data with Weather",
        generatedAt: new Date().toISOString()
      }
    };

    const responseHeaders = {
      ...corsHeaders,
      'Content-Type': 'application/json'
    };

    if (nextCursor) {
      responseHeaders['x-next-cursor'] = nextCursor;
    }

    return new Response(JSON.stringify(responseData), {
      headers: responseHeaders
    });

  } catch (error) {
    console.error('Stream error:', error);
    
    return new Response(JSON.stringify({
      error: {
        code: 'STREAM_ERROR',
        message: error.message
      }
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
})
