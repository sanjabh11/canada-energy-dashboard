Deno.serve(async (req) => {
    const corsHeaders = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
        'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
        'Access-Control-Max-Age': '86400',
        'Access-Control-Allow-Credentials': 'false'
    };

    if (req.method === 'OPTIONS') {
        return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
        // Get the service role key
        const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
        const supabaseUrl = Deno.env.get('SUPABASE_URL');

        if (!serviceRoleKey || !supabaseUrl) {
            throw new Error('Supabase configuration missing');
        }

        // Create the source_health table
        const createTableQuery = `
            CREATE TABLE IF NOT EXISTS source_health (
                id SERIAL PRIMARY KEY,
                created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
                source_name TEXT NOT NULL,
                status_code INTEGER NOT NULL,
                is_success BOOLEAN NOT NULL,
                details JSONB
            );
        `;

        const response = await fetch(`${supabaseUrl}/rest/v1/rpc/create_source_health_table`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${serviceRoleKey}`,
                'apikey': serviceRoleKey,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({})
        });

        // If the RPC doesn't exist, try direct SQL execution
        if (!response.ok) {
            // Try creating via direct SQL query (if available)
            const sqlResponse = await fetch(`${supabaseUrl}/rest/v1/query`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${serviceRoleKey}`,
                    'apikey': serviceRoleKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    query: createTableQuery
                })
            });

            if (!sqlResponse.ok) {
                // As fallback, insert a test record which will create the table structure
                const insertResponse = await fetch(`${supabaseUrl}/rest/v1/source_health`, {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${serviceRoleKey}`,
                        'apikey': serviceRoleKey,
                        'Content-Type': 'application/json',
                        'Prefer': 'return=minimal'
                    },
                    body: JSON.stringify({
                        source_name: 'setup_test',
                        status_code: 200,
                        is_success: true,
                        details: { message: 'Table setup verification' }
                    })
                });

                if (!insertResponse.ok) {
                    const errorText = await insertResponse.text();
                    throw new Error(`Table creation failed: ${errorText}`);
                }
            }
        }

        return new Response(JSON.stringify({
            data: {
                message: 'Monitoring table setup completed successfully',
                table_name: 'source_health',
                timestamp: new Date().toISOString()
            }
        }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });

    } catch (error) {
        console.error('Setup error:', error);

        const errorResponse = {
            error: {
                code: 'SETUP_FAILED',
                message: error.message
            }
        };

        return new Response(JSON.stringify(errorResponse), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
    }
});