import { serve } from "https://deno.land/std@0.208.0/http/server.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    
    // Extract source and dataset from path: /manifest/kaggle/provincial_generation
    const source = pathParts[2]; // kaggle
    const dataset = pathParts[3]; // provincial_generation
    
    if (source !== 'kaggle' || dataset !== 'provincial_generation') {
      return new Response(JSON.stringify({ 
        error: { code: 'DATASET_NOT_FOUND', message: 'Dataset not supported' } 
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get Kaggle credentials from environment (or use demo mode)
    const kaggleUsername = Deno.env.get('KAGGLE_USERNAME') || 'demo';
    const kaggleKey = Deno.env.get('KAGGLE_KEY') || 'demo';
    
    const isDemoMode = kaggleUsername === 'demo' || kaggleKey === 'demo';
    
    if (isDemoMode) {
      console.log('Running in demo mode - returning static manifest');
    }

    // Prepare Kaggle API request (skip in demo mode)
    if (!isDemoMode) {
      const auth = btoa(`${kaggleUsername}:${kaggleKey}`);
      const kaggleUrl = 'https://www.kaggle.com/api/v1/datasets/download/jacobsharples/provincial-energy-production-canada';
      
      console.log('Fetching dataset manifest from Kaggle...');
      
      // For manifest, we just need to fetch the first chunk to understand schema
      const response = await fetch(kaggleUrl, {
        headers: {
          'Authorization': `Basic ${auth}`,
          'User-Agent': 'CEIP-Supabase-Function/1.0'
        }
      });

      if (!response.ok) {
        console.error(`Kaggle API error: ${response.status} ${response.statusText}`);
        return new Response(JSON.stringify({
          error: { code: 'KAGGLE_API_ERROR', message: `Kaggle API returned ${response.status}` }
        }), {
          status: 502,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    // Note: In a real implementation, you'd need to handle the ZIP file download
    // and extract the CSV. For this manifest endpoint, we'll provide a static schema
    // based on what we know about the dataset structure.
    
    const manifest = {
      dataset: 'kaggle/provincial_generation',
      version: '1.0',
      schema: {
        fields: [
          { name: 'date', type: 'string', description: 'Year-month in YYYY-MM format' },
          { name: 'province', type: 'string', description: 'Canadian province or territory name' },
          { name: 'producer', type: 'string', description: 'Type of electricity producer' },
          { name: 'generation_type', type: 'string', description: 'Type of electricity generation' },
          { name: 'megawatt_hours', type: 'number', description: 'Energy generated in megawatt hours' }
        ]
      },
      sampleRows: [
        {
          "date": "2008-01",
          "province": "Alberta", 
          "producer": "electric utilities",
          "generation_type": "combustible fuels",
          "megawatt_hours": 4671109.0
        },
        {
          "date": "2008-01",
          "province": "Alberta",
          "producer": "electric utilities", 
          "generation_type": "hydraulic turbine",
          "megawatt_hours": 135167.0
        },
        {
          "date": "2008-01",
          "province": "Alberta",
          "producer": "electric utilities",
          "generation_type": "wind power turbine", 
          "megawatt_hours": 12979.0
        }
      ],
      estimatedRows: 50000,
      recommendedLimit: 1000,
      metadata: {
        description: 'Canadian provincial electricity generation by source and producer type',
        source: isDemoMode ? 'Demo Mode - Static Data' : 'Kaggle - jacobsharples/provincial-energy-production-canada',
        lastUpdated: '2025-01-01T00:00:00Z',
        coverage: {
          dateRange: '2008-01 to 2023-12',
          provinces: ['Alberta', 'British Columbia', 'Manitoba', 'New Brunswick', 'Newfoundland and Labrador', 'Northwest Territories', 'Nova Scotia', 'Nunavut', 'Ontario', 'Prince Edward Island', 'Quebec', 'Saskatchewan', 'Yukon'],
          generationTypes: ['combustible fuels', 'hydraulic turbine', 'nuclear steam turbine', 'solar', 'wind power turbine', 'other types of electricity generation', 'tidal power turbine']
        }
      }
    };

    console.log('Manifest generated successfully');

    return new Response(JSON.stringify(manifest), {
      headers: { 
        ...corsHeaders, 
        'Content-Type': 'application/json',
        'Cache-Control': 'public, max-age=300' // Cache for 5 minutes
      }
    });

  } catch (error) {
    console.error('Error in manifest function:', error);
    
    const errorResponse = {
      error: {
        code: 'INTERNAL_ERROR',
        message: error.message
      }
    };

    return new Response(JSON.stringify(errorResponse), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
})
