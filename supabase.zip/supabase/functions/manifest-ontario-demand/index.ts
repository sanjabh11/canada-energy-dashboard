import { serve } from "https://deno.land/std@0.208.0/http/server.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    
    // Extract source and dataset from path: /manifest/kaggle/ontario_demand
    const source = pathParts[pathParts.length - 2] || 'kaggle';  
    const dataset = pathParts[pathParts.length - 1] || 'ontario_demand';

    // Manifest function doesn't need credentials - just returns metadata
    // Credentials are only needed for actual data streaming functions

    // Define schema based on research findings
    const schema = {
      fields: [
        {
          name: "datetime",
          type: "string", 
          description: "Timestamp in ISO format (YYYY-MM-DD HH:mm:ss)"
        },
        {
          name: "hour_ending",
          type: "integer",
          description: "Hour of day (1-24, EST year-round)"
        },
        {
          name: "total_demand_mw",
          type: "number",
          description: "Total Ontario electricity demand in megawatts"
        },
        {
          name: "hourly_demand_gwh",
          type: "number", 
          description: "Hourly demand in gigawatt hours"
        },
        {
          name: "date",
          type: "string",
          description: "Date in YYYY-MM-DD format"
        }
      ]
    };

    // Sample data based on Ontario demand patterns
    const sampleRows = [
      {
        datetime: "2023-01-15 08:00:00",
        hour_ending: 8,
        total_demand_mw: 18456.7,
        hourly_demand_gwh: 18.457,
        date: "2023-01-15"
      },
      {
        datetime: "2023-01-15 09:00:00", 
        hour_ending: 9,
        total_demand_mw: 19234.2,
        hourly_demand_gwh: 19.234,
        date: "2023-01-15"
      },
      {
        datetime: "2023-07-22 14:00:00",
        hour_ending: 14,
        total_demand_mw: 22187.9,
        hourly_demand_gwh: 22.188,
        date: "2023-07-22"
      }
    ];

    const manifestData = {
      dataset: `${source}/ontario_demand`,
      version: "1.0",
      schema,
      sampleRows,
      estimatedRows: 175000,
      recommendedLimit: 1000,
      metadata: {
        description: "Ontario electricity demand data with hourly granularity",
        source: "Demo Mode - Static Data",
        lastUpdated: "2025-01-01T00:00:00Z",
        coverage: {
          dateRange: "2003-01 to 2023-12",
          granularity: "Hourly",
          timezone: "EST",
          peakDemand: "~25,000 MW (summer)",
          baseDemand: "~13,000 MW (overnight)"
        }
      }
    };

    return new Response(JSON.stringify(manifestData), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('Manifest error:', error);
    
    return new Response(JSON.stringify({
      error: {
        code: 'MANIFEST_ERROR',
        message: error.message
      }
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
})
