import { serve } from "https://deno.land/std@0.208.0/http/server.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    
    // Extract source and dataset from path: /manifest/kaggle/provincial_generation
    const source = pathParts[pathParts.length - 2] || 'kaggle';  
    const dataset = pathParts[pathParts.length - 1] || 'provincial_generation';

    // Manifest function doesn't need credentials - just returns metadata
    // Credentials are only needed for actual data streaming functions

    // Define schema based on provincial generation data
    const schema = {
      fields: [
        {
          name: "date",
          type: "string", 
          description: "Date in YYYY-MM-DD format"
        },
        {
          name: "province",
          type: "string",
          description: "Canadian province name"
        },
        {
          name: "producer",
          type: "string",
          description: "Energy producer/utility company"
        },
        {
          name: "generation_type",
          type: "string",
          description: "Type of generation (nuclear, hydro, wind, etc.)"
        },
        {
          name: "mwh",
          type: "number",
          description: "Generation in megawatt hours"
        },
        {
          name: "source",
          type: "string",
          description: "Data source identifier"
        }
      ]
    };

    // Sample data based on Canadian provincial generation patterns
    const sampleRows = [
      {
        date: "2008-01-01",
        province: "Alberta",
        producer: "electric utilities",
        generation_type: "combustible fuels",
        mwh: 3239396.63,
        source: "kaggle"
      },
      {
        date: "2008-01-02", 
        province: "British Columbia",
        producer: "electric utilities",
        generation_type: "hydraulic turbine",
        mwh: 5710813.43,
        source: "kaggle"
      },
      {
        date: "2008-01-03",
        province: "Ontario",
        producer: "electric utilities",
        generation_type: "nuclear steam turbine",
        mwh: 8413294.73,
        source: "kaggle"
      }
    ];

    const manifestData = {
      dataset: `${source}/provincial_generation`,
      version: "1.0",
      schema,
      sampleRows,
      estimatedRows: 500000,
      recommendedLimit: 1000,
      metadata: {
        description: "Canadian provincial electricity generation data by source",
        source: "Kaggle - Canadian electricity generation by source",
        lastUpdated: "2025-01-01T00:00:00Z",
        coverage: {
          dateRange: "2008-01 to 2023-12",
          provinces: ["Alberta", "British Columbia", "Manitoba", "New Brunswick", "Nova Scotia", "Ontario", "Quebec", "Saskatchewan"],
          generationTypes: ["nuclear", "hydro", "wind power", "solar", "combustible fuels"],
          granularity: "Daily"
        }
      }
    };

    return new Response(JSON.stringify(manifestData), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('Provincial generation manifest error:', error);
    
    return new Response(JSON.stringify({
      error: {
        code: 'MANIFEST_ERROR',
        message: error.message
      }
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
})
