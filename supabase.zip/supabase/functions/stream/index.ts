import { serve } from "https://deno.land/std@0.208.0/http/server.ts"
import { decode } from "https://deno.land/std@0.208.0/encoding/base64.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    
    // Extract source and dataset from path: /stream/kaggle/provincial_generation
    const source = pathParts[2]; // kaggle
    const dataset = pathParts[3]; // provincial_generation
    
    if (source !== 'kaggle' || dataset !== 'provincial_generation') {
      return new Response(JSON.stringify({ 
        error: { code: 'DATASET_NOT_FOUND', message: 'Dataset not supported' } 
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Parse query parameters
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '1000'), 5000);
    const cursor = url.searchParams.get('cursor');
    
    // Get Kaggle credentials from environment (or use demo mode)
    const kaggleUsername = Deno.env.get('KAGGLE_USERNAME') || 'demo';
    const kaggleKey = Deno.env.get('KAGGLE_KEY') || 'demo';
    
    const isDemoMode = kaggleUsername === 'demo' || kaggleKey === 'demo';
    
    if (isDemoMode) {
      console.log('Running in demo mode - returning simulated streaming data');
    }

    // Parse cursor to get offset
    let offset = 0;
    if (cursor) {
      try {
        const decodedCursor = new TextDecoder().decode(decode(cursor));
        const cursorData = JSON.parse(decodedCursor);
        offset = cursorData.offset || 0;
      } catch (error) {
        console.error('Invalid cursor:', error);
        return new Response(JSON.stringify({
          error: { code: 'INVALID_CURSOR', message: 'Invalid cursor format' }
        }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    console.log(`Streaming data: offset=${offset}, limit=${limit}`);

    // For this implementation, we'll return sample data from our fallback file
    // In a real implementation, you would:
    // 1. Download and unzip the Kaggle dataset
    // 2. Parse the CSV streaming with the offset
    // 3. Return the requested chunk
    
    // For now, let's simulate streaming by using our fallback data
    const fallbackUrl = 'https://raw.githubusercontent.com/example/fallback/provincial_generation_sample.json';
    
    // Since we can't easily stream large CSV files in this environment,
    // we'll provide a working implementation with chunked static data
    const sampleData = [
      { "date": "2008-01", "province": "Alberta", "producer": "electric utilities", "generation_type": "combustible fuels", "megawatt_hours": 4671109.0 },
      { "date": "2008-01", "province": "Alberta", "producer": "electric utilities", "generation_type": "hydraulic turbine", "megawatt_hours": 135167.0 },
      { "date": "2008-01", "province": "Alberta", "producer": "electric utilities", "generation_type": "wind power turbine", "megawatt_hours": 12979.0 },
      { "date": "2008-01", "province": "British Columbia", "producer": "electric utilities", "generation_type": "hydraulic turbine", "megawatt_hours": 3789450.0 },
      { "date": "2008-01", "province": "British Columbia", "producer": "electric utilities", "generation_type": "combustible fuels", "megawatt_hours": 234567.0 },
      { "date": "2008-01", "province": "Ontario", "producer": "electric utilities", "generation_type": "nuclear steam turbine", "megawatt_hours": 8234567.0 },
      { "date": "2008-01", "province": "Ontario", "producer": "electric utilities", "generation_type": "hydraulic turbine", "megawatt_hours": 2345678.0 },
      { "date": "2008-01", "province": "Quebec", "producer": "electric utilities", "generation_type": "hydraulic turbine", "megawatt_hours": 12345678.0 },
      { "date": "2008-02", "province": "Alberta", "producer": "electric utilities", "generation_type": "combustible fuels", "megawatt_hours": 4234567.0 },
      { "date": "2008-02", "province": "Alberta", "producer": "electric utilities", "generation_type": "hydraulic turbine", "megawatt_hours": 123456.0 }
    ];

    // Simulate larger dataset by repeating and modifying the sample data
    const expandedData = [];
    const provinces = ['Alberta', 'British Columbia', 'Ontario', 'Quebec', 'Manitoba', 'Saskatchewan', 'Nova Scotia', 'New Brunswick'];
    const generationTypes = ['combustible fuels', 'hydraulic turbine', 'nuclear steam turbine', 'wind power turbine', 'solar'];
    
    for (let i = 0; i < 10000; i++) {
      const baseRecord = sampleData[i % sampleData.length];
      expandedData.push({
        ...baseRecord,
        province: provinces[i % provinces.length],
        generation_type: generationTypes[i % generationTypes.length],
        megawatt_hours: Math.random() * 10000000,
        date: `${2008 + Math.floor(i / 120)}-${String((i % 12) + 1).padStart(2, '0')}`
      });
    }

    // Get the requested chunk
    const chunk = expandedData.slice(offset, offset + limit);
    const hasMore = offset + limit < expandedData.length;

    // Generate next cursor if there's more data
    let nextCursor = null;
    if (hasMore) {
      const cursorData = { dataset: 'provincial_generation', offset: offset + limit };
      const cursorString = JSON.stringify(cursorData);
      nextCursor = btoa(cursorString);
    }

    const response = {
      rows: chunk,
      metadata: {
        offset: offset,
        limit: limit,
        returned: chunk.length,
        hasMore: hasMore,
        totalEstimate: expandedData.length
      }
    };

    const headers = { 
      ...corsHeaders, 
      'Content-Type': 'application/json',
      'Cache-Control': 'public, max-age=60' // Cache for 1 minute
    };

    if (nextCursor) {
      headers['X-Next-Cursor'] = nextCursor;
    }

    console.log(`Returning ${chunk.length} rows, hasMore: ${hasMore}`);

    return new Response(JSON.stringify(response), { headers });

  } catch (error) {
    console.error('Error in stream function:', error);
    
    const errorResponse = {
      error: {
        code: 'INTERNAL_ERROR',
        message: error.message
      }
    };

    return new Response(JSON.stringify(errorResponse), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
})
