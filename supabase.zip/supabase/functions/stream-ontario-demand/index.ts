import { serve } from "https://deno.land/std@0.208.0/http/server.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    
    // Parse query parameters
    const cursor = url.searchParams.get('cursor') || '0';
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '1000'), 5000);
    const offset = parseInt(cursor, 10);

    // Get credentials from environment or request body
    let kaggleUsername = Deno.env.get('KAGGLE_USERNAME');
    let kaggleKey = Deno.env.get('KAGGLE_KEY');

    if (!kaggleUsername || !kaggleKey) {
      try {
        const body = await req.json();
        kaggleUsername = body.kaggleUsername;
        kaggleKey = body.kaggleKey;
      } catch (e) {
        // Continue without credentials for demo
      }
    }

    // Generate synthetic Ontario demand data based on research patterns
    const generateOntarioDemandData = (startOffset: number, count: number) => {
      const rows = [];
      const baseDate = new Date('2023-01-01');
      
      for (let i = 0; i < count; i++) {
        const currentDate = new Date(baseDate);
        currentDate.setHours(currentDate.getHours() + startOffset + i);
        
        const hour = currentDate.getHours();
        const month = currentDate.getMonth();
        const isWeekend = currentDate.getDay() === 0 || currentDate.getDay() === 6;
        
        // Ontario demand patterns: higher in summer/winter, peak during business hours
        let baseDemand = 16000; // Base MW
        
        // Seasonal adjustment
        if (month >= 5 && month <= 8) baseDemand += 4000; // Summer AC load
        if (month >= 11 || month <= 2) baseDemand += 2000; // Winter heating
        
        // Daily pattern
        if (hour >= 7 && hour <= 18 && !isWeekend) {
          baseDemand += 3000; // Business hours
        } else if (hour >= 19 && hour <= 22) {
          baseDemand += 1500; // Evening peak
        }
        
        // Add some randomness
        const demand = baseDemand + (Math.random() - 0.5) * 2000;
        
        rows.push({
          datetime: currentDate.toISOString().slice(0, 19).replace('T', ' '),
          hour_ending: hour === 0 ? 24 : hour,
          total_demand_mw: Math.round(demand * 100) / 100,
          hourly_demand_gwh: Math.round(demand * 0.001 * 100) / 100,
          date: currentDate.toISOString().slice(0, 10)
        });
      }
      
      return rows;
    };

    const rows = generateOntarioDemandData(offset, limit);
    const hasMore = offset + limit < 175000; // Based on research: ~175,000 hourly records
    const nextCursor = hasMore ? (offset + limit).toString() : null;

    const responseData = {
      rows,
      metadata: {
        offset,
        limit,
        returned: rows.length,
        hasMore,
        totalEstimate: 175000,
        dataSource: "Demo Mode - Generated Ontario Demand Data",
        generatedAt: new Date().toISOString()
      }
    };

    const responseHeaders = {
      ...corsHeaders,
      'Content-Type': 'application/json'
    };

    if (nextCursor) {
      responseHeaders['x-next-cursor'] = nextCursor;
    }

    return new Response(JSON.stringify(responseData), {
      headers: responseHeaders
    });

  } catch (error) {
    console.error('Stream error:', error);
    
    return new Response(JSON.stringify({
      error: {
        code: 'STREAM_ERROR',
        message: error.message
      }
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
})
