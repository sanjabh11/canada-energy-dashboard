import { serve } from "https://deno.land/std@0.208.0/http/server.ts"

serve(async (req) => {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS, PUT, DELETE, PATCH',
    'Access-Control-Max-Age': '86400',
    'Access-Control-Allow-Credentials': 'false'
  };

  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const pathParts = url.pathname.split('/');
    
    // Extract source and dataset from path
    const source = pathParts[pathParts.length - 2] || 'huggingface';  
    const dataset = pathParts[pathParts.length - 1] || 'hf_electricity_demand';

    // Get Hugging Face token from environment or request body
    let hfToken = Deno.env.get('HF_TOKEN');

    if (!hfToken) {
      try {
        const body = await req.json();
        hfToken = body.hfToken || body.huggingFaceToken;
      } catch (e) {
        // Continue without token for demo
      }
    }

    // Define schema based on EDS-lab/electricity-demand dataset structure
    const schema = {
      fields: [
        {
          name: "datetime",
          type: "string", 
          description: "Timestamp in ISO format"
        },
        {
          name: "household_id",
          type: "string",
          description: "Unique identifier for the household/smart meter"
        },
        {
          name: "electricity_demand",
          type: "number",
          description: "Electricity demand in kW"
        },
        {
          name: "temperature",
          type: "number", 
          description: "Ambient temperature in Celsius"
        },
        {
          name: "humidity",
          type: "number",
          description: "Relative humidity percentage"
        },
        {
          name: "wind_speed",
          type: "number",
          description: "Wind speed in m/s"
        },
        {
          name: "solar_irradiance",
          type: "number",
          description: "Solar irradiance in W/m²"
        },
        {
          name: "location",
          type: "string",
          description: "Geographical location identifier"
        },
        {
          name: "day_of_week",
          type: "integer",
          description: "Day of week (0=Monday, 6=Sunday)"
        },
        {
          name: "hour",
          type: "integer",
          description: "Hour of day (0-23)"
        }
      ]
    };

    // Sample data reflecting smart meter demand patterns with weather features
    const sampleRows = [
      {
        datetime: "2023-06-15T08:30:00Z",
        household_id: "HH_001_UK_LONDON",
        electricity_demand: 2.45,
        temperature: 18.7,
        humidity: 65.2,
        wind_speed: 4.8,
        solar_irradiance: 420,
        location: "UK_LONDON",
        day_of_week: 3,
        hour: 8
      },
      {
        datetime: "2023-06-15T08:30:00Z",
        household_id: "HH_002_DE_BERLIN", 
        electricity_demand: 1.89,
        temperature: 21.3,
        humidity: 58.1,
        wind_speed: 6.2,
        solar_irradiance: 380,
        location: "DE_BERLIN",
        day_of_week: 3,
        hour: 8
      },
      {
        datetime: "2023-12-10T19:45:00Z",
        household_id: "HH_003_FR_PARIS",
        electricity_demand: 4.12,
        temperature: 3.8,
        humidity: 78.5,
        wind_speed: 8.1,
        solar_irradiance: 0,
        location: "FR_PARIS", 
        day_of_week: 6,
        hour: 19
      }
    ];

    const manifestData = {
      dataset: `${source}/hf_electricity_demand`,
      version: "1.0", 
      schema,
      sampleRows,
      estimatedRows: 8760000, // ~1000 households * 8760 hours/year * multiple years
      recommendedLimit: 1000,
      metadata: {
        description: "Smart meter electricity demand data with weather features (based on EDS-lab/electricity-demand)",
        source: "Demo Mode - Static Data",
        lastUpdated: "2025-01-01T00:00:00Z",
        coverage: {
          dateRange: "2019-01 to 2023-12",
          granularity: "15-minute intervals",
          timezone: "UTC",
          households: "~1000 smart meters across Europe",
          weatherFeatures: "Temperature, Humidity, Wind Speed, Solar Irradiance",
          locations: ["UK_LONDON", "DE_BERLIN", "FR_PARIS", "ES_MADRID", "IT_ROME", "NL_AMSTERDAM"]
        }
      }
    };

    return new Response(JSON.stringify(manifestData), {
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });

  } catch (error) {
    console.error('Manifest error:', error);
    
    return new Response(JSON.stringify({
      error: {
        code: 'MANIFEST_ERROR',
        message: error.message
      }
    }), {
      status: 500,
      headers: {
        ...corsHeaders,
        'Content-Type': 'application/json'
      }
    });
  }
})
