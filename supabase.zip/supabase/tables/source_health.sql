CREATE TABLE source_health (
    id SERIAL PRIMARY KEY,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text,
    NOW()) NOT NULL,
    source_name TEXT NOT NULL,
    status_code INTEGER NOT NULL,
    is_success BOOLEAN NOT NULL,
    details JSONB
);